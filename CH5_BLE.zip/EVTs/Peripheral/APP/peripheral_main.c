/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.c
 * Author             : CanHobby.ca based on original EVT examples frpmm WCH
 * Version            : V1.1
 * Date               : 2026/05/05
 * Description        : Basic MCU ststus and control via BLE using LigtBLUE App
 *********************************************************************************/

/******************************************************************************/
#include "CONFIG.h"
#include "HAL.h"
#include "gattprofile.h"
#include "peripheral.h"

/*********************************************************************
 * GLOBAL TYPEDEFS
 */
__attribute__((aligned(4))) uint32_t MEM_BUF[BLE_MEMHEAP_SIZE / 4];

#if(defined(BLE_MAC)) && (BLE_MAC == TRUE)
const uint8_t MacAddr[6] = {0x84, 0xC2, 0xE4, 0x03, 0x02, 0x02};
#endif

char CHIP_Type = CHP_TYPE;
char Cid[16];

extern void timer();

/*********************************************************************
 * @fn      Main_Circulation
 *
 * @brief   ��ѭ��
 *
 * @return  none
 */
__HIGH_CODE
__attribute__((noinline))
void Main_Circulation()
{
    while(1)
    {
        TMOS_SystemProcess();
    }
}

/*********************************************************************
 * @fn      main
 *
 * @return  none
 */
int main(void)
{
#if(defined(DCDC_ENABLE)) && (DCDC_ENABLE == TRUE)
    PWR_DCDCCfg(ENABLE);
#endif
    SetSysClock(CLK_SOURCE_PLL_60MHz);
#if(defined(HAL_SLEEP)) && (HAL_SLEEP == TRUE)
    GPIOA_ModeCfg(GPIO_Pin_All, GPIO_ModeIN_PU);
    GPIOB_ModeCfg(GPIO_Pin_All, GPIO_ModeIN_PU);
#endif
#ifdef DEBUG
    GPIOA_SetBits( GPIO_Pin_9 | LED_Pin );
    GPIOA_ModeCfg( bTXD1 | LED_Pin, GPIO_ModeOut_PP_5mA);
    GPIOB_ModeCfg( GPIO_Pin_22, GPIO_ModeIN_PU );  //  Boot Pin
    UART1_DefInit();

//#if( defined( BLE_MAC)) && (BLE_MAC == TRUE)
#if( defined( CHP_TYPE )) && ( CHP_TYPE == 'M' )
    GPIOB_SetBits( GPIO_Pin_4 );
    GPIOB_ModeCfg( GPIO_Pin_4, GPIO_ModeOut_PP_5mA);
#endif

#if( defined( CHP_TYPE )) && ( CHP_TYPE == 'F' )
//    GPIOA_ResetBits( GPIO_Pin_8 );
//    GPIOA_ModeCfg( GPIO_Pin_8, GPIO_ModeOut_PP_5mA);

//    UART1_DefInit();

// GPIOB_ModeCfg( GPIO_Pin_22, GPIO_ModeIN_PU );  // BOOT Pin mayaa

#endif

#endif

timer( 30 ); // set for 1 Sec. blink = 60MHz clock / 2 because we are using set Inverse
printf("Internal Temp = %dC\n", adc_to_temperature_celsius( HAL_GetInterTempValue() ) );

printf("BOOT Pin is %s\n", GPIOB_ReadPortPin(GPIO_Pin_22) ? "not Pressed" : "Pressed" );

//    memcpy( attDeviceName, Cid, 5 );

    CH58X_BLEInit();
    HAL_Init();
    GAPRole_PeripheralInit();
    Peripheral_Init();
    Main_Circulation();
}

/******************************** endfile @ main ******************************/
