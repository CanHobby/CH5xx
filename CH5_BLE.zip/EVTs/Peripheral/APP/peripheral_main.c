/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.c
 * Author             : CanHobby.ca based on original EVT examples frpmm WCH
 * Version            : V1.1
 * Date               : 2026/05/05
 * Description        : Basic MCU ststus and control via BLE using LigtBLUE App
 *********************************************************************************/

/******************************************************************************/
#include "CONFIG.h"
#include "HAL.h"
#include "gattprofile.h"
#include "peripheral.h"

/*********************************************************************
 * GLOBAL TYPEDEFS
 */
__attribute__((aligned(4))) uint32_t MEM_BUF[BLE_MEMHEAP_SIZE / 4];

#if(defined(BLE_MAC)) && (BLE_MAC == TRUE)
const uint8_t MacAddr[6] = {0x84, 0xC2, 0xE4, 0x03, 0x02, 0x02};
#endif

char CHIP_Type;
char Cid[16];
int  LED_Pin; // = GPIO_Pin_8 for 'F'

extern void timer();

/*********************************************************************
 * @fn      Main_Circulation
 *
 * @brief   ��ѭ��
 *
 * @return  none
 */
__HIGH_CODE
__attribute__((noinline))
void Main_Circulation()
{
    while(1)
    {
        TMOS_SystemProcess();
    }
}

/*********************************************************************
 * @fn      main
 *
 * @return  none
 */
int main(void)
{

    SetSysClock(CLK_SOURCE_PLL_60MHz);

    GPIOA_SetBits( bTXD1 );
    GPIOA_ModeCfg( bTXD1, GPIO_ModeOut_PP_5mA);
    GPIOB_ModeCfg( GPIO_Pin_22, GPIO_ModeIN_PU );  //  Boot Pin
    UART1_DefInit();

printf( "\nCH5_BLE\n" );

// Determin Chip Model

sprintf(Cid,"CH5%X\n", R8_CHIP_ID );
if( Cid[5] == '2' ) {
    CHIP_Type = 'F';
    LED_Pin = GPIO_Pin_8;     
    GPIOA_SetBits( LED_Pin );
    GPIOA_ModeCfg( LED_Pin, GPIO_ModeOut_PP_5mA);
     
  } else {
    CHIP_Type = 'M'; 
    LED_Pin = GPIO_Pin_4;  
    GPIOB_SetBits( LED_Pin );
    GPIOB_ModeCfg( LED_Pin, GPIO_ModeOut_PP_5mA);
        }

sprintf(Cid,"CH5%X%c\n", R8_CHIP_ID, CHIP_Type );        
printf("80: Cid = %s\n", Cid ); 

timer( 30 ); // set for 1 Sec. blink = 60MHz clock / 2 because we are using set Inverse

printf("Internal Temp = %dC\n", adc_to_temperature_celsius( HAL_GetInterTempValue() ) );

printf("BOOT Pin is %s\n", GPIOB_ReadPortPin(GPIO_Pin_22) ? "not Pressed" : "Pressed" );

    CH58X_BLEInit();
    HAL_Init();
    GAPRole_PeripheralInit();
    Peripheral_Init();
    Main_Circulation();
}

/******************************** endfile @ main ******************************/
