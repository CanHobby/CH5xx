/********************************** (C) COPYRIGHT *******************************
 * File Name          : Main.c
 * Author             : WCH
 * Version            : V1.0
 * Date               : 2020/08/06
 * Description        : ��ʱ������
 *********************************************************************************
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * Attention: This software (modified or not) and binary are used for 
 * microcontroller manufactured by Nanjing Qinheng Microelectronics.
 *******************************************************************************/

#include "CH58x_common.h"

// __attribute__((aligned(4))) uint32_t CapBuf[100];
// __attribute__((aligned(4))) uint32_t PwmBuf[100];

// volatile uint8_t capFlag = 0;

extern char CHIP_Type;
extern int  LED_Pin;

/*********************************************************************
 * @fn      main
 *
 * @return  none
 */
void timer( int x )
{
    uint8_t i;

printf("timer() %c %X\n", CHIP_Type, LED_Pin );

TMR0_TimerInit( x * 1000000 );  //  millions of uSec

    TMR0_ITCfg(ENABLE, TMR0_3_IT_CYC_END);
    PFIC_EnableIRQ(TMR0_IRQn);

}

/*********************************************************************
 * @fn      TMR0_IRQHandler
 *
 * @return  none
 */
__INTERRUPT
__HIGH_CODE
void TMR0_IRQHandler(void) // TMR0
{
    if(TMR0_GetITFlag(TMR0_3_IT_CYC_END))
    {
        TMR0_ClearITFlag(TMR0_3_IT_CYC_END);
        if( CHIP_Type == 'F') { GPIOA_InverseBits(LED_Pin); }  /* PA8-LED */
        if( CHIP_Type == 'M') { GPIOB_InverseBits(LED_Pin); } /* PB4-LED */
    }
}
